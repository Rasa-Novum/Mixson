package net.rasanovum.runeweaver.hooks;

import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.rasanovum.runeweaver.util.Index;
import net.rasanovum.runeweaver.util.RuneweaverUtil;
import net.rasanovum.runeweaver.util.VersionUtils;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;

@ApiStatus.Internal
public class NamespaceHook extends AbstractHook<List<class_3298>> {

    private final class_2960 resourceId;

    public NamespaceHook(List<class_3298> attachedResources, class_2960 resourceId) {
        super(attachedResources);
        this.resourceId = resourceId;
    }

    @Override
    public Optional<List<class_3298>> captureFiles(Index index, String fileExt) {
        if(!VersionUtils.withSuffix(index.id(), fileExt).equals(this.resourceId))
            return Optional.empty();
        if(index.ordinal() == -1) return Optional.of(this.attachedResources);
        return Optional.of(List.of(this.attachedResources.get(index.ordinal())));
    }

    @Override
    public List<Map.Entry<Index, class_3298>> getMatching(Predicate<Index> predicate) {
        List<Map.Entry<Index, class_3298>> result = new ArrayList<>();
        class_2960 withoutExtension = RuneweaverUtil.removeExtension(this.resourceId);
        for(int i = 0; i < this.attachedResources.size(); i++) {
            if(!predicate.test(new Index(this.resourceId, i))) continue;
            result.add(Map.entry(new Index(withoutExtension, i), this.attachedResources.get(i)));
        }
        return result;
    }

    @Override
    public void insert(Index index, List<class_3298> resources, String fileExt, boolean overwrite) {
        if(!VersionUtils.withSuffix(index.id(), fileExt).equals(this.resourceId))
            throw new IllegalArgumentException("Namespace Hook cannot process index " + index + " with id: " + this.resourceId);
        if(index.ordinal() == -1) {
            if(!overwrite)
                throw new IllegalStateException("Cannot set resource: missing overwrite permission");
            this.attachedResources.clear();
            this.attachedResources.addAll(resources);
            return;
        }
        if(resources.size() != 1)
            throw new IllegalArgumentException("Cannot insert resource: list with index "+index);
        class_3298 resource = resources.get(0);
        if(index.ordinal() >= this.attachedResources.size())
            throw new IllegalStateException("Cannot overwrite resource: Resource with index " + index + " does not exists");
        if(overwrite)
            this.attachedResources.set(index.ordinal(), resource);
        else
            attachedResources.add(index.ordinal(), resource);
    }

    @Override
    public void delete(Index index, String fileExt) {
        if(!VersionUtils.withSuffix(index.id(), fileExt).equals(this.resourceId))
            throw new IllegalArgumentException("Namespace Hook cannot process index " + index + "with id: " + this.resourceId);
        if(index.ordinal() >= this.attachedResources.size())
            throw new IllegalStateException("Cannot delete resource: Resource with index " + index + " does not exists");
        if(index.ordinal() == -1)
            this.attachedResources.clear();
        else
            this.attachedResources.remove(index.ordinal());
    }
}
