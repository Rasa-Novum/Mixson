package net.rasanovum.runeweaver.util.interfaces;

import net.minecraft.class_2960;
import net.rasanovum.runeweaver.enums.ErrorPolicy;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface ErrorMessageProvider {

    String getRuntimeErrorMessage(class_2960 resourceId);

    String getRegistrationErrorMessage();

    ErrorPolicy getErrorPolicy();

    String getRegistrationMessage(int priority);
}
