package net.rasanovum.runeweaver.mixins;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3304;
import net.minecraft.class_6861;
import net.rasanovum.runeweaver.Runeweaver;
import net.rasanovum.runeweaver.hooks.ListHook;
import net.rasanovum.runeweaver.hooks.StandardHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.Map;

@Mixin({class_6861.class, class_3304.class})
public class ResourceManagerImplMixinArray {

    @ModifyReturnValue(method = "listResources", at = @At("RETURN"))
    private Map<class_2960, class_3298> runRuneweaverEvents(Map<class_2960, class_3298> original) {
        return Runeweaver.processHook(new StandardHook(original));
    }

    @ModifyReturnValue(method = "listResourceStacks", at = @At("RETURN"))
    private Map<class_2960, List<class_3298>> runListRuneweaverEvents(Map<class_2960, List<class_3298>> original) {
        return Runeweaver.processHook(new ListHook(original));
    }
}
