package net.rasanovum.runeweaver.hooks;

import net.minecraft.class_3298;
import net.rasanovum.runeweaver.util.Index;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;

public abstract class AbstractHook<T> {

    protected final T attachedResources;

    public AbstractHook(T attachedResources) {
        this.attachedResources = attachedResources;
    }

    public abstract Optional<List<class_3298>> captureFiles(Index index, String fileExt);

    public abstract List<Map.Entry<Index, class_3298>> getMatching(Predicate<Index> predicate);

    public abstract void insert(Index index, List<class_3298> resources, String fileExt, boolean overwrite);

    public void insert(Index index, class_3298 resource, String fileExt, boolean overwrite) {
        insert(index, List.of(resource), fileExt, overwrite);
    }

    public abstract void delete(Index index, String fileExt);

    public T getAttachedResources() {
        return attachedResources;
    }
}
