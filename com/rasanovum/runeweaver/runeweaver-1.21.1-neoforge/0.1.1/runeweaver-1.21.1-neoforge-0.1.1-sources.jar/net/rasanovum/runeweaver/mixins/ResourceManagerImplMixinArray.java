package net.rasanovum.runeweaver.mixins;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.MultiPackResourceManager;
import net.minecraft.server.packs.resources.ReloadableResourceManager;
import net.minecraft.server.packs.resources.Resource;
import net.rasanovum.runeweaver.Runeweaver;
import net.rasanovum.runeweaver.hooks.ListHook;
import net.rasanovum.runeweaver.hooks.StandardHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.Map;

@Mixin({MultiPackResourceManager.class, ReloadableResourceManager.class})
public class ResourceManagerImplMixinArray {

    @ModifyReturnValue(method = "listResources", at = @At("RETURN"))
    private Map<ResourceLocation, Resource> runRuneweaverEvents(Map<ResourceLocation, Resource> original) {
        return Runeweaver.processHook(new StandardHook(original));
    }

    @ModifyReturnValue(method = "listResourceStacks", at = @At("RETURN"))
    private Map<ResourceLocation, List<Resource>> runListRuneweaverEvents(Map<ResourceLocation, List<Resource>> original) {
        return Runeweaver.processHook(new ListHook(original));
    }
}
