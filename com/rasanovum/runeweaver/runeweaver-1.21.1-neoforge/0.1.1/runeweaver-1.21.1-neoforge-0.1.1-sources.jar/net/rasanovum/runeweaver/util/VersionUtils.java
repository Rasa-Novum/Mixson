package net.rasanovum.runeweaver.util;

import net.minecraft.resources.ResourceLocation;

import java.util.Objects;

public final class VersionUtils {

    private VersionUtils() {
    }

    public static ResourceLocation id(String value) {
        //? if >1.20.1 {
        return ResourceLocation.parse(value);
        //?} else {
        /*return new ResourceLocation(value);
        *///?}
    }

    public static ResourceLocation id(String namespace, String path) {
        //? if >1.20.1 {
        return ResourceLocation.fromNamespaceAndPath(namespace, path);
        //?} else {
        /*return new ResourceLocation(namespace, path);
        *///?}
    }

    public static ResourceLocation withSuffix(ResourceLocation id, String suffix) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(suffix, "suffix");
        //? if >=26.1 {
        /*return id.withSuffix(suffix);
        *///?} else {
        return id.withPath(path(id) + suffix);
        //?}
    }

    public static String namespace(ResourceLocation id) {
        return id.getNamespace();
    }

    public static String path(ResourceLocation id) {
        return id.getPath();
    }
}
