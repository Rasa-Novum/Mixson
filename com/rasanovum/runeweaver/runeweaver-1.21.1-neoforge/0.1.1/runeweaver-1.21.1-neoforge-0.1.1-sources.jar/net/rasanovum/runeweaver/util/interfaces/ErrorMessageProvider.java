package net.rasanovum.runeweaver.util.interfaces;

import net.minecraft.resources.ResourceLocation;
import net.rasanovum.runeweaver.enums.ErrorPolicy;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface ErrorMessageProvider {

    String getRuntimeErrorMessage(ResourceLocation resourceId);

    String getRegistrationErrorMessage();

    ErrorPolicy getErrorPolicy();

    String getRegistrationMessage(int priority);
}
