package net.rasanovum.runeweaver.util;

import java.util.Objects;
import net.minecraft.class_2960;

public final class VersionUtils {

    private VersionUtils() {
    }

    public static class_2960 id(String value) {
        //? if >1.20.1 {
        /*return ResourceLocation.parse(value);
        *///?} else {
        return new class_2960(value);
        //?}
    }

    public static class_2960 id(String namespace, String path) {
        //? if >1.20.1 {
        /*return ResourceLocation.fromNamespaceAndPath(namespace, path);
        *///?} else {
        return new class_2960(namespace, path);
        //?}
    }

    public static class_2960 withSuffix(class_2960 id, String suffix) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(suffix, "suffix");
        //? if >=26.1 {
        /*return id.withSuffix(suffix);
        *///?} else {
        return id.method_45136(path(id) + suffix);
        //?}
    }

    public static String namespace(class_2960 id) {
        return id.method_12836();
    }

    public static String path(class_2960 id) {
        return id.method_12832();
    }
}
