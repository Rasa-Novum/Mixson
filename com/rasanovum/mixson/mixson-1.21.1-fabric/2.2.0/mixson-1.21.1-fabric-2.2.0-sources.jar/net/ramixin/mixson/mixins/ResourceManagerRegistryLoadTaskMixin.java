package net.ramixin.mixson.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_7654;
import net.ramixin.mixson.Mixson;
import net.ramixin.mixson.hooks.StandardHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Map;

//? if >=26.1 {
/*@Mixin(targets = "net.minecraft.resources.ResourceManagerRegistryLoadTask")
*///?} else {
@Mixin(targets = "net.minecraft.resources.RegistryDataLoader")
//?}
public class ResourceManagerRegistryLoadTaskMixin {

    @WrapOperation(
            //? if >=26.1 {
            /*method = "lambda$load$0",
            *///?} else if >1.20.1 {
            method = "loadContentsFromManager",
            //?} else {
            /*method = "loadRegistryContents",
            *///?}
            at = @At(value = "INVOKE", target = "Lnet/minecraft/resources/FileToIdConverter;listMatchingResources(Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map;")
    )
    private static Map<class_2960, class_3298> runMixsonEvents(class_7654 instance, class_3300 resourceManager, Operation<Map<class_2960, class_3298>> original) {
        return Mixson.processHook(new StandardHook(original.call(instance, resourceManager)));
    }
}
