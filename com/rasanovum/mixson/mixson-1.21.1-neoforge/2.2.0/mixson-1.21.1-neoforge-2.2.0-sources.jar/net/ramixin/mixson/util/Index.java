package net.ramixin.mixson.util;

import net.minecraft.resources.ResourceLocation;

import java.util.Objects;

@SuppressWarnings("ClassCanBeRecord") // NO IT CANNOT
public final class Index implements Comparable<Index> {

    private final ResourceLocation id;
    private final int ordinal;

    public Index(ResourceLocation id, int ordinal) {
        this.id = id;
        if(ordinal < -1) throw new IllegalArgumentException("Ordinal must be greater than or equal to -1");
        this.ordinal = ordinal;
    }

    public Index(String stringId, int ordinal) {
        this(VersionUtils.id(stringId), ordinal);
    }

    public Index(ResourceLocation id) {
        this(id, 0);
    }

    public Index(String stringId) {
        this(VersionUtils.id(stringId), 0);
    }

    public Index withSuffixedId(String suffix) {
        return new Index(VersionUtils.withSuffix(id, suffix), ordinal);
    }

    @Override
    public String toString() {
        return "Index{namespace=" +
                VersionUtils.namespace(id) +
                ", path=" +
                VersionUtils.path(id) +
                ", ordinal=" +
                ordinal +
                '}';
    }

    @Override
    public int compareTo(Index other) {
        int idCompare = this.id.compareTo(other.id);
        if (idCompare != 0)
            return idCompare;
        return Integer.compare(this.ordinal, other.ordinal);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Index index)) return false;
        return ordinal == index.ordinal && Objects.equals(id, index.id);
    }

    public boolean idEquals(Index other) {
        return this.id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, ordinal);
    }

    public Index copy() {
        return new Index(VersionUtils.id(id.toString()), ordinal);
    }

    public ResourceLocation id() {
        return id;
    }

    public int ordinal() {
        return ordinal;
    }
}
