package net.ramixin.mixson.util.interfaces;

import net.minecraft.resources.ResourceLocation;
import net.ramixin.mixson.enums.ErrorPolicy;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface ErrorMessageProvider {

    String getRuntimeErrorMessage(ResourceLocation resourceId);

    String getRegistrationErrorMessage();

    ErrorPolicy getErrorPolicy();

    String getRegistrationMessage(int priority);
}
