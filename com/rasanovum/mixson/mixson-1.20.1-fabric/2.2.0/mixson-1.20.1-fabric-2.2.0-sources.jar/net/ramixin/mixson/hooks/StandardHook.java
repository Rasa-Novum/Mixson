package net.ramixin.mixson.hooks;

import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.ramixin.mixson.util.Index;
import net.ramixin.mixson.util.MixsonUtil;
import net.ramixin.mixson.util.VersionUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@ApiStatus.Internal
public class StandardHook extends AbstractHook<Map<class_2960, class_3298>> {

    public StandardHook(Map<class_2960, class_3298> attachedResources) {
        super(attachedResources);
    }

    @Override
    public Optional<List<class_3298>> captureFiles(@NotNull Index index, String fileExt) {
        if(index.ordinal() > 0)
            return Optional.empty();
        class_3298 resource = this.attachedResources.get(VersionUtils.withSuffix(index.id(), fileExt));
        if(resource == null) return Optional.empty();
        return Optional.of(List.of(resource));
    }

    @Override
    public List<Map.Entry<Index, class_3298>> getMatching(Predicate<Index> predicate) {
        return this.attachedResources
                .entrySet()
                .stream()
                .filter((entry) -> predicate.test(new Index(entry.getKey(), 0)))
                .map(entry -> Map.entry(new Index(MixsonUtil.removeExtension(entry.getKey()), 0), entry.getValue()))
                .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public void insert(@NotNull Index index, List<class_3298> resources, String fileExt, boolean overwrite) {
        if(resources.isEmpty())
            throw new IllegalArgumentException("Cannot insert empty resource list");
        if(index.ordinal()+1 > 1)
            throw new IllegalArgumentException("Resource type does not support ordinal indexing");
        if(this.attachedResources.put(VersionUtils.withSuffix(index.id(), fileExt), resources.get(0)) == null && overwrite)
            throw new IllegalStateException("Cannot overwrite resource: Resource with id " + index + " does not exists");
    }

    @Override
    public void delete(Index index, String fileExt) {
        if(index.ordinal() < 1)
            this.attachedResources.remove(VersionUtils.withSuffix(index.id(), fileExt));
    }
}
