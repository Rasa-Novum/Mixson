package net.ramixin.mixson;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_3298;
import net.ramixin.mixson.util.interfaces.MixsonCodec;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

@SuppressWarnings("unused")
public interface MixsonCodecs {

    MixsonCodec<JsonElement> JSON_ELEMENT = new MixsonCodec<>() {
        @Override
        public String extensionAndDot() {
            return ".json";
        }

        @Override
        public JsonElement deserialize(class_3298 r) throws IOException {
            return JsonParser.parseReader(r.method_43039());
        }

        @Override
        public class_3298 serialize(class_3298 r, JsonElement x) {
            return new class_3298(r.method_45304(), () -> new ByteArrayInputStream(x.toString().getBytes()), r::method_14481);
        }

        @Override
        public ByteArrayOutputStream export(JsonElement resource) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(new GsonBuilder().setPrettyPrinting().create().toJson(resource).getBytes());
            return baos;
        }
    };

    MixsonCodec<BufferedImage> PNG = new MixsonCodec<>() {
        @Override
        public String extensionAndDot() {
            return ".png";
        }

        @Override
        public BufferedImage deserialize(class_3298 r) throws IOException {
            return ImageIO.read(r.method_14482());
        }

        @Override
        public class_3298 serialize(class_3298 r, BufferedImage x) {
            return new class_3298(r.method_45304(), () -> new ByteArrayInputStream(bufferedImageToStream(x).toByteArray()), r::method_14481);
        }

        @Override
        public ByteArrayOutputStream export(BufferedImage r) throws IOException {
            return bufferedImageToStream(r);
        }
    };

    MixsonCodec<class_2487> NBT = new MixsonCodec<>() {
        @Override
        public String extensionAndDot() {
            return ".nbt";
        }

        @Override
        public class_2487 deserialize(class_3298 r) throws IOException {
            //? if >1.20.1 {
            /*return NbtIo.readCompressed(r.open(), NbtAccounter.unlimitedHeap());
            *///?} else {
            return class_2507.method_10629(r.method_14482());
            //?}
        }

        @Override
        public class_3298 serialize(class_3298 r, class_2487 x) {
            return new class_3298(r.method_45304(), () -> new ByteArrayInputStream(nbtToStream(x).toByteArray()), r::method_14481);
        }

        @Override
        public ByteArrayOutputStream export(class_2487 r) throws IOException {
            return nbtToStream(r);
        }
    };

    private static ByteArrayOutputStream bufferedImageToStream(BufferedImage image) throws IOException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        ImageIO.write(image, "png", stream);
        return stream;
    }

    private static ByteArrayOutputStream nbtToStream(class_2487 compound) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        class_2507.method_10634(compound, baos);
        return baos;
    }

}
