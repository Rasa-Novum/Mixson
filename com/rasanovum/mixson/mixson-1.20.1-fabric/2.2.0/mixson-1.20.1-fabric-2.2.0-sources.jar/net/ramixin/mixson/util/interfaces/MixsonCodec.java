package net.ramixin.mixson.util.interfaces;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import net.minecraft.class_3298;

public interface MixsonCodec<T> {

    String extensionAndDot();

    T deserialize(class_3298 resource) throws IOException;

    class_3298 serialize(class_3298 associatedResource, T elem) throws IOException;

    ByteArrayOutputStream export(T resource) throws IOException;
}
