package net.ramixin.mixson.mixins;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2960;
import net.minecraft.class_3294;
import net.minecraft.class_3298;
import net.ramixin.mixson.Mixson;
import net.ramixin.mixson.hooks.NamespaceHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Mixin(class_3294.class)
public class NamespaceResourceManagerMixin {


    @ModifyReturnValue(method = "getResourceStack", at = @At("RETURN"))
    private List<class_3298> runMixsonEvents(List<class_3298> original, @Local(argsOnly = true) class_2960 id) {
        return Mixson.processHook(new NamespaceHook(original, id));
    }

    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    @ModifyReturnValue(method = "getResource", at = @At("RETURN"))
    private Optional<class_3298> runMixsonEvents(Optional<class_3298> original, class_2960 id) {
        if(original.isEmpty()) return Optional.empty();
        List<class_3298> result = Mixson.processHook(new NamespaceHook(new ArrayList<>(List.of(original.get())), id));
        return Optional.ofNullable(result.get(0));
    }
}
