package net.ramixin.mixson.hooks;

import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.ramixin.mixson.util.Index;
import net.ramixin.mixson.util.MixsonUtil;
import net.ramixin.mixson.util.VersionUtils;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;

@ApiStatus.Internal
public class ListHook extends AbstractHook<Map<class_2960, List<class_3298>>> {

    public ListHook(Map<class_2960, List<class_3298>> attachedResources) {
        super(attachedResources);
    }

    @Override
    public Optional<List<class_3298>> captureFiles(Index index, String fileExt) {
        List<class_3298> list = this.attachedResources.get(VersionUtils.withSuffix(index.id(), fileExt));
        if(list == null) return Optional.empty();
        if(index.ordinal() == -1) return Optional.of(list);
        return Optional.of(List.of(list.get(index.ordinal())));
    }

    @Override
    public List<Map.Entry<Index, class_3298>> getMatching(Predicate<Index> predicate) {
        List<Map.Entry<Index, class_3298>> result = new ArrayList<>();
        for(Map.Entry<class_2960, List<class_3298>> entry : this.attachedResources.entrySet()) {
            for(int i = 0; i < entry.getValue().size(); i++) {
                if(predicate.test(new Index(entry.getKey(), i))) {
                    result.add(Map.entry(new Index(MixsonUtil.removeExtension(entry.getKey()), i), entry.getValue().get(i)));
                }
            }
        }
        return result;
    }

    @Override
    public void insert(Index index, List<class_3298> resources, String fileExt, boolean overwrite) {
        if(resources.isEmpty())
            throw new IllegalArgumentException("Cannot insert empty resource list");
        Index suffixedIndex = index.withSuffixedId(fileExt);
        List<class_3298> immutableList = this.attachedResources.get(suffixedIndex.id());
        if(index.ordinal() == -1) {
            if(immutableList == null)
                this.attachedResources.put(suffixedIndex.id(), resources);
            else if(!overwrite)
                throw new IllegalStateException("Cannot set list resource without overwrite permission");
            else this.attachedResources.put(suffixedIndex.id(), resources);
            return;
        }
        if(resources.size() != 1)
            throw new IllegalArgumentException("Cannot insert resource list with index "+index);
        class_3298 resource = resources.get(0);
        List<class_3298> mutableList = new ArrayList<>(immutableList != null ? immutableList : List.of());
        if(overwrite)
            mutableList.set(index.ordinal(), resource);
        else
            mutableList.add(index.ordinal(), resource);
        this.attachedResources.put(suffixedIndex.id(), mutableList);
    }

    @Override
    public void delete(Index index, String fileExt) {
        List<class_3298> immutableList = this.attachedResources.get(VersionUtils.withSuffix(index.id(), fileExt));
        if(immutableList == null) return;
        List<class_3298> mutableList = new ArrayList<>(immutableList);
        if(index.ordinal() >= mutableList.size())
            throw new IllegalStateException("Cannot delete resource: Resource with index " + index + " does not exists");
        mutableList.remove(index.ordinal());
        this.attachedResources.put(VersionUtils.withSuffix(index.id(), fileExt), mutableList);
    }
}
