package net.ramixin.mixson.mixins;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3304;
import net.minecraft.class_6861;
import net.ramixin.mixson.Mixson;
import net.ramixin.mixson.hooks.ListHook;
import net.ramixin.mixson.hooks.StandardHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.Map;

@Mixin({class_6861.class, class_3304.class})
public class ResourceManagerImplMixinArray {

    @ModifyReturnValue(method = "listResources", at = @At("RETURN"))
    private Map<class_2960, class_3298> runMixsonEvents(Map<class_2960, class_3298> original) {
        return Mixson.processHook(new StandardHook(original));
    }

    @ModifyReturnValue(method = "listResourceStacks", at = @At("RETURN"))
    private Map<class_2960, List<class_3298>> runListMixsonEvents(Map<class_2960, List<class_3298>> original) {
        return Mixson.processHook(new ListHook(original));
    }
}
